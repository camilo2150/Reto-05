class Shape:
    def compute_area(self):
        pass

    def compute_perimeter(self):
        pass
