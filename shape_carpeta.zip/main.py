from shape.shape_module import Rectangle as Rectangle1, Square as Square1
from shape.rectangle import Rectangle as Rectangle2
from shape.square import Square as Square2

print("=== Desde shape_module (Módulo único) ===")
shapes = [Rectangle1(4, 6), Square1(5)]
for shape in shapes:
    print(f"Figura: {type(shape).__name__}")
    print(f"Área: {shape.compute_area()}")
    print(f"Perímetro: {shape.compute_perimeter()}")
    print("-" * 40)

print("\n=== Desde módulos individuales ===")
shapes = [Rectangle2(2, 3), Square2(7)]
for shape in shapes:
    print(f"Figura: {type(shape).__name__}")
    print(f"Área: {shape.compute_area()}")
    print(f"Perímetro: {shape.compute_perimeter()}")
    print("-" * 40)
