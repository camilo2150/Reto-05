print("=== Opción 1: Usando shape_module.py ===")
import shape_module

shapes1 = [shape_module.Rectangle(4, 5), shape_module.Square(3)]
for s in shapes1:
    print(f"Área: {s.compute_area()}, Perímetro: {s.compute_perimeter()}")

print("\n=== Opción 2: Usando módulos separados ===")
from rectangle import Rectangle
from square import Square

shapes2 = [Rectangle(2, 6), Square(4)]
for s in shapes2:
    print(f"Área: {s.compute_area()}, Perímetro: {s.compute_perimeter()}")
