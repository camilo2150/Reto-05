from .shape import Shape
from .rectangle import Rectangle
from .square import Square
