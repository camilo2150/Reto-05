class Shape:
    def compute_area(self):
        raise NotImplementedError("Este método debe ser redefinido en la subclase.")

    def compute_perimeter(self):
        raise NotImplementedError("Este método debe ser redefinido en la subclase.")
