class Shape:
    def compute_area(self):
        raise NotImplementedError("Este método debe ser redefinido en la subclase.")

    def compute_perimeter(self):
        raise NotImplementedError("Este método debe ser redefinido en la subclase.")

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def compute_area(self):
        return self.width * self.height

    def compute_perimeter(self):
        return 2 * (self.width + self.height)

class Square(Shape):
    def __init__(self, side):
        self.side = side

    def compute_area(self):
        return self.side ** 2

    def compute_perimeter(self):
        return 4 * self.side
